
<!DOCTYPE html>
<html>
<head>
<style>
table 
{
  width: 100%;
  border-collapse: collapse;
}

table, td, th 
{
  border: 1px solid black;
  padding: 5px;
}

th {text-align: left;}

</style>
</head>
<body>

<?php


// Load Variables
$uid="root";

$pwd="root";

$database="BIT695";

$host = '127.0.0.1:3306';

$con = mysqli_connect($host,$uid,$pwd,$database);
if (!$con) {
  die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,"BIT695");
$sql="SELECT LoanID FROM loans";
$result = mysqli_query($con,$sql);

if ($result != 0) {  //Export Result to HTML
    echo '<label>Select LoanID:';
    echo '<select id="selectLoanList">';

    $num_results = mysqli_num_rows($result);
    for ($i=0;$i<$num_results;$i++) {
        $row = mysqli_fetch_array($result);
        $name = $row['LoanID'];
        echo '<option value="' .$name. '">' .$name. '</option>';
    }

    echo '</select>';
    echo '</label>';
}

mysqli_close($con);

?>

</body>
</html> 