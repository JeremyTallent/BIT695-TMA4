
<?php 

// Load Variables
$SelectedDay = intval($_GET['Day']);

$UpdatedTime = $_GET['Time'];

$UpdatedVenue = $_GET['Venue'];

$uid="root";

$pwd="root";

$database="BIT695";

$host = '127.0.0.1:3306';

function connect_db($host, $uid, $pwd, $database) {  	

	$conn=mysqli_connect($host, $uid, $pwd, $database)

	or die('connection problem:' . mysqli_connect_error());

	return $conn;

}

$conn=connect_db($host,$uid,$pwd,$database);

$sql = "UPDATE schedule SET Time = '{$UpdatedTime}', Venue = '{$UpdatedVenue}' WHERE ID = {$SelectedDay}";

if ($conn->query($sql) === TRUE) {  //Validate PHP Query
  echo "Record added successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

?> 
