<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3.css">

<style>

body, h1,h2,h3,h4,h5,h6 {font-family: sans-serif}
.w3-row-padding img {margin-bottom: 12px}
/* Set the width of the sidebar to 120px */
.w3-sidebar {width: 120px;background: #C6E8F9;}
/* Add a left margin to the "page content" that matches the width of the sidebar (120px) */
#main {margin-left: 120px}
/* Remove margins from "page content" on small screens */
@media only screen and (max-width: 600px) {#main {margin-left: 0}}
table 
{
  width: 100%;
  border-collapse: collapse;
}

table, td, th 
{
  border: 1px solid black;
  padding: 5px;
}

th {text-align: left;}

</style>
</head>
<body>

<?php


// Load Variables
$uid="root";

$pwd="root";

$database="BIT695";

$host = '127.0.0.1:3306';

$con = mysqli_connect($host,$uid,$pwd,$database);

if (!$con) 
{
  die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,"BIT695");


$sql = "SELECT players.FirstName, players.FamilyName, scores.Game, scores.Score FROM players INNER JOIN scores ON players.MemberID=scores.PlayerID ORDER BY Score DESC LIMIT 0,10";

$result = mysqli_query($con,$sql);
  //Export Result to HTML
echo "
<table>
<tr>
<th>FirstName</th>
<th>LastName</th>
<th>Game</th>
<th>Score</th>
</tr>";

while($row = mysqli_fetch_array($result)) {
  echo "<tr>";
  echo "<td>" . $row['FirstName'] . "</td>";
  echo "<td>" . $row['FamilyName'] . "</td>";
  echo "<td>" . $row['Game'] . "</td>";
  echo "<td>" . $row['Score'] . "</td>";
  echo "</tr>";
}

echo "</table>";

mysqli_close($con);

?>

</body>
</html>