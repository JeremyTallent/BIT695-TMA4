
<?php 

// Load Variables
$Game = $_GET['Game'];

$Player = $_GET['Player']; 

$uid="root";

$pwd="root";

$database="BIT695";

$host = '127.0.0.1:3306';

function connect_db($host, $uid, $pwd, $database) {  	

	$conn=mysqli_connect($host, $uid, $pwd, $database)

	or die('connection problem:' . mysqli_connect_error());

	return $conn;

}

$conn=connect_db($host,$uid,$pwd,$database);

$sql = "INSERT INTO loans (BorrowerID, Game) VALUES ('{$Player}', '{$Game}')";

if ($conn->query($sql) === TRUE) {  //Validate PHP Query
  echo "Record added successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

?> 
