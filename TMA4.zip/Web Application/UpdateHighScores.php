
<?php 


// Load Variables
$Score = intval($_GET['Score']);

$Player = $_GET['Player'];

$Game = $_GET['Game'];

$uid="root";

$pwd="root";

$database="BIT695";

$host = '127.0.0.1:3306';

function connect_db($host, $uid, $pwd, $database) {  	

	$conn=mysqli_connect($host, $uid, $pwd, $database)

	or die('connection problem:' . mysqli_connect_error());

	return $conn;

}

$conn=connect_db($host,$uid,$pwd,$database);

$sql = "INSERT INTO scores (PlayerID, Game, Score) VALUES ('{$Player}', '{$Game}', {$Score})";

if ($conn->query($sql) === TRUE) {  //Validate PHP Query
  echo "Record added successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

?> 
