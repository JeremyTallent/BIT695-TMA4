INSERT INTO games (Name) VALUES ('Connect Four'); 
INSERT INTO games (Name) VALUES ('Monopoly'); 
INSERT INTO games (Name) VALUES ('Scrabble'); 
INSERT INTO games (Name) VALUES ('Battleship'); 
INSERT INTO games (Name) VALUES ('Chess'); 
INSERT INTO games (Name) VALUES ('Checkers'); 
INSERT INTO games (Name) VALUES ('Uno'); 
INSERT INTO games (Name) VALUES ('Othello'); 
INSERT INTO games (Name) VALUES ('Rook'); 
INSERT INTO games (Name) VALUES ('Axis and Allies'); 

INSERT INTO loans (BorrowerID, Game) VALUES ('1', 'Monopoly');
INSERT INTO loans (BorrowerID, Game) VALUES ('2', 'Scrabble');
INSERT INTO loans (BorrowerID, Game) VALUES ('3', 'Othello');
INSERT INTO loans (BorrowerID, Game) VALUES ('4', 'Axis and Allies');
INSERT INTO loans (BorrowerID, Game) VALUES ('5', 'Checkers');
INSERT INTO loans (BorrowerID, Game) VALUES ('1', 'Uno');
INSERT INTO loans (BorrowerID, Game) VALUES ('2', 'Chess');
INSERT INTO loans (BorrowerID, Game) VALUES ('1', 'Connect Four');
INSERT INTO loans (BorrowerID, Game) VALUES ('4', 'Monopoly');
INSERT INTO loans (BorrowerID, Game) VALUES ('5', 'Rook'); 

INSERT INTO players (MemberID, FirstName, FamilyName, Email, Phone, DisplayName) VALUES ("1", "Jeremy", "Tallent", "jeremytallent@myop.ac.nz", "5839673957", "1-JeremyTallent");
INSERT INTO players (MemberID, FirstName, FamilyName, Email, Phone, DisplayName) VALUES ("2", "Danile", "Thompson", "Danile.Thompson@gmail.com", "328590349", "2-DanileThompson");
INSERT INTO players (MemberID, FirstName, FamilyName, Email, Phone, DisplayName) VALUES ("3", "Francis", "Remis", "FrannyRemis@avd.ac.nz", "296810746", "3-FrancisRemis");
INSERT INTO players (MemberID, FirstName, FamilyName, Email, Phone, DisplayName) VALUES ("4", "Kim", "Glover", "Kimberly@protonmail.com", "196395836", "4-KimGlover");
INSERT INTO players (MemberID, FirstName, FamilyName, Email, Phone, DisplayName) VALUES ("5", "Jennifer", "Atkins", "JennyCC@outlook.com", "047328751", "5-JenniferAtkins"); 

INSERT INTO schedule (ID, Day, Time, Venue) VALUES (1, 'Monday', '7:00pm', 'Clubs and Socs - R2.14');
INSERT INTO schedule (ID, Day, Time, Venue) VALUES (2, 'Tuesday', 'No Game', 'No Game');
INSERT INTO schedule (ID, Day, Time, Venue) VALUES (3, 'Wednesday', '7:00pm', 'Clubs and Socs - R2.16');
INSERT INTO schedule (ID, Day, Time, Venue) VALUES (4, 'Thursday',  'No Game', 'No Game');
INSERT INTO schedule (ID, Day, Time, Venue) VALUES (5, 'Friday', '8:00pm', 'Cavern Tavern - Gallery');
INSERT INTO schedule (ID, Day, Time, Venue) VALUES (6, 'Saturday',  'No Game', 'No Game');
INSERT INTO schedule (ID, Day, Time, Venue) VALUES (7, 'Sunday',  'No Game', 'No Game');

INSERT INTO scores (PlayerID, Game, Score) VALUES (1, 'Monopoly', 487);
INSERT INTO scores (PlayerID, Game, Score) VALUES (2, 'Scrabble', 254);
INSERT INTO scores (PlayerID, Game, Score) VALUES (3, 'Othello', 852);
INSERT INTO scores (PlayerID, Game, Score) VALUES (4, 'Uno', 13);
INSERT INTO scores (PlayerID, Game, Score) VALUES (5, 'Monopoly', 645);
INSERT INTO scores (PlayerID, Game, Score) VALUES (2, 'Rook', 867);
INSERT INTO scores (PlayerID, Game, Score) VALUES (4, 'Checkers', 286);
INSERT INTO scores (PlayerID, Game, Score) VALUES (1, 'Monopoly', 386);
INSERT INTO scores (PlayerID, Game, Score) VALUES (3, 'Connect Four', 495);
INSERT INTO scores (PlayerID, Game, Score) VALUES (1, 'Chess', 27);
INSERT INTO scores (PlayerID, Game, Score) VALUES (2, 'Monopoly', 98);
INSERT INTO scores (PlayerID, Game, Score) VALUES (5, 'Chess', 102);
INSERT INTO scores (PlayerID, Game, Score) VALUES (4, 'Monopoly', 469);
INSERT INTO scores (PlayerID, Game, Score) VALUES (2, 'Monopoly', 340);
INSERT INTO scores (PlayerID, Game, Score) VALUES (1, 'Monopoly', 189); 

INSERT INTO venues (Name) VALUES ('Clubs and Socs - R2.14'); 
INSERT INTO venues (Name) VALUES ('Clubs and Socs - R2.15'); 
INSERT INTO venues (Name) VALUES ('Clubs and Socs - R2.16'); 
INSERT INTO venues (Name) VALUES ('Clubs and Socs - R2.17'); 
INSERT INTO venues (Name) VALUES ('Cavern Tavern - Ball Room'); 
INSERT INTO venues (Name) VALUES ('Cavern Tavern - Gallery'); 
INSERT INTO venues (Name) VALUES ('No Game'); 