CREATE TABLE scores (
    PlayerID int(5) NOT NULL,
    Game varchar(20) NOT NULL,
	Score int(20) NOT NULL
); 