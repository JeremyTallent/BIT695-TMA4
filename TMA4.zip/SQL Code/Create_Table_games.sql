CREATE TABLE games (
    Name varchar(30) NOT NULL,
    PRIMARY KEY (Name)
); 