CREATE TABLE loans (
    LoanID int(6) NOT NULL AUTO_INCREMENT,
    BorrowerID varchar(6) NOT NULL,
    Game varchar(30) NOT NULL,
    PRIMARY KEY (LoanID)
); 