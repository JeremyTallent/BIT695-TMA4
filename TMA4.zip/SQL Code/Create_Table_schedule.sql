CREATE TABLE schedule (
    ID int(2),
    Day varchar(20),
    Time varchar(20),
	Venue varchar(30)
); 