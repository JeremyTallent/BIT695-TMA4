CREATE TABLE venues (
    Name varchar(30) NOT NULL
); 