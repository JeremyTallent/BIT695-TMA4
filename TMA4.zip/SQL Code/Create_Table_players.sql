CREATE TABLE players (
    MemberID varchar(20) NOT NULL,
    FirstName varchar(20),
    FamilyName varchar(20),
	Email varchar(40),
	Phone varchar(20),
	DisplayName varchar(30),
    PRIMARY KEY (MemberID)
); 